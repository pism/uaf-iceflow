
static char help[] = "Runs Conway's game of Life in parallel.\n";

#include <petscda.h>

#define abs(i) ((i < 0) ? -i : i)

//PetscScalar lifeRule(PetscScalar me, PetscScalar nsum) {
double lifeRule(double me, double nsum) {
   if (fabs(me - 0.0) < 0.1) { // dead cell
     if (fabs(nsum - 3.0) < 0.1)  return 1.0;
     else  return 0.0;
   } else { // live cell
     if (nsum < 1.9)  return 0.0;
     else if (nsum > 3.1)  return 0.0;
     else  return 1.0;
   }
}

int main(int argc, char *argv[]) {
  PetscErrorCode  ierr;
  PetscInt        myM = 60, myN = 60, midi, midj, i, j, k, gi, gj, max_steps = 1000;
  DA 	            da2;
  DALocalInfo     info;
  PetscViewer     viewer, ascifile;
  PetscDraw       draw;
  Vec             gstate, lstate;
  PetscScalar     **st, **oldst;
  PetscScalar     startPattern[5][5] = {{1.0, 1.0, 1.0, 0.0, 1.0},
                                        {1.0, 0.0, 0.0, 0.0, 0.0},
                                        {0.0, 0.0, 0.0, 1.0, 1.0},
                                        {0.0, 1.0, 1.0, 0.0, 1.0},
                                        {1.0, 0.0, 1.0, 0.0, 1.0}};

  // start up and read options
  ierr = PetscInitialize(&argc, &argv, PETSC_NULL, help); CHKERRQ(ierr);
  ierr = PetscOptionsGetInt(PETSC_NULL, "-M", &myM, PETSC_NULL); CHKERRQ(ierr);
  ierr = PetscOptionsGetInt(PETSC_NULL, "-N", &myN, PETSC_NULL); CHKERRQ(ierr);
  midi = (myM-2)/2;  midj = (myN-2)/2;
  ierr = PetscOptionsGetInt(PETSC_NULL, "-steps", &max_steps, PETSC_NULL); CHKERRQ(ierr);

  // create DA which is periodic and has BOX stencil width 1; note Life involve all 8 neighbors
  ierr = DACreate2d(PETSC_COMM_WORLD, DA_XYPERIODIC, DA_STENCIL_BOX, myM, myN, 
             PETSC_DECIDE, PETSC_DECIDE, 1, 1, PETSC_NULL, PETSC_NULL, &da2); CHKERRQ(ierr);
  ierr = DAGetLocalInfo(da2, &info); CHKERRQ(ierr);
  ierr = DACreateGlobalVector(da2, &gstate); CHKERRQ(ierr);

  // setup state: zeros except for 5x5 special block in center
  ierr = VecSet(gstate,0.0); CHKERRQ(ierr);
  ierr = DAVecGetArray(da2, gstate, &st); CHKERRQ(ierr);
  for (i = 0; i < 5; ++i) {
    for (j = 0; j < 5; ++j) {
      gi = i + midi;  gj = j + midj;
      if ((gi >= info.xs) & (gi < info.xs+info.xm) & (gj >= info.ys) & (gj < info.ys+info.ym)) {
        st[gj][gi] = startPattern[j][i];
      }
    }
  }
  ierr = DAVecRestoreArray(da2, gstate, &st); CHKERRQ(ierr);

  // set ghosted values on each processor
  ierr = DACreateLocalVector(da2, &lstate); CHKERRQ(ierr);
  ierr = DAGlobalToLocalBegin(da2, gstate, INSERT_VALUES, lstate); CHKERRQ(ierr);
  ierr = DAGlobalToLocalEnd(da2, gstate, INSERT_VALUES, lstate); CHKERRQ(ierr);

  // view initial state
  ierr = PetscViewerDrawOpen(PETSC_COMM_WORLD, PETSC_NULL, "",
             PETSC_DECIDE, PETSC_DECIDE, 700, 700, &viewer);  CHKERRQ(ierr);
  ierr = VecView(gstate, viewer); CHKERRQ(ierr);
  ierr = PetscViewerDrawGetDraw(viewer,0,&draw); CHKERRQ(ierr);
//  ierr = PetscDrawSetDoubleBuffer(draw); CHKERRQ(ierr);
  ierr = PetscSleep(3); CHKERRQ(ierr);

  // run life and view at each stage
  for (k = 0; k < max_steps; k++) {
    ierr = DAVecGetArray(da2, gstate, &st); CHKERRQ(ierr);
    ierr = DAVecGetArray(da2, lstate, &oldst); CHKERRQ(ierr);
    for (i=info.xs; i<info.xs+info.xm; ++i) {
      for (j=info.ys; j<info.ys+info.ym; ++j) {
        st[j][i] = lifeRule(oldst[j][i], 
                            oldst[j][i+1] + oldst[j-1][i+1] + oldst[j-1][i] + oldst[j-1][i-1] +
                            oldst[j][i-1] + oldst[j+1][i-1] + oldst[j+1][i] + oldst[j+1][i+1]);
      }
    }
    ierr = DAVecRestoreArray(da2, lstate, &oldst); CHKERRQ(ierr);
    ierr = DAVecRestoreArray(da2, gstate, &st); CHKERRQ(ierr);
    // update ghosted values from new (global) state on each processor
    ierr = DAGlobalToLocalBegin(da2, gstate, INSERT_VALUES, lstate); CHKERRQ(ierr);
    ierr = DAGlobalToLocalEnd(da2, gstate, INSERT_VALUES, lstate); CHKERRQ(ierr);
    ierr = VecView(gstate, viewer); CHKERRQ(ierr);
    ierr = PetscSleep(0.2); CHKERRQ(ierr);
  }
  ierr = PetscViewerDestroy(viewer); CHKERRQ(ierr);
  ierr = VecDestroy(lstate); CHKERRQ(ierr);

  // save to text file at end
  ierr = PetscViewerASCIIOpen(PETSC_COMM_WORLD, "life.out", &ascifile);  CHKERRQ(ierr);
  ierr = VecView(gstate, ascifile); CHKERRQ(ierr);
  ierr = PetscViewerDestroy(ascifile); CHKERRQ(ierr);
  
  ierr = VecDestroy(gstate); CHKERRQ(ierr);
  ierr = DADestroy(da2); CHKERRQ(ierr);
  ierr = PetscFinalize(); CHKERRQ(ierr);
  return 0;
}
