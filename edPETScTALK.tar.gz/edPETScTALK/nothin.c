
static char help[] = "A string which the user might find helpful\
 when they type nothin -help.\n";

#include <petscvec.h>

int main(int argc, char *argv[]) {
  PetscErrorCode  ierr;
  PetscMPIInt rank, size;

  ierr = PetscInitialize(&argc, &argv, PETSC_NULL, help); CHKERRQ(ierr);
  ierr = MPI_Comm_rank(PETSC_COMM_WORLD, &rank); CHKERRQ(ierr);
  ierr = MPI_Comm_size(PETSC_COMM_WORLD, &size); CHKERRQ(ierr);

  // this will print once for each process:
  ierr = PetscPrintf(PETSC_COMM_SELF,"rank = %d\n",rank);CHKERRQ(ierr);
  // this will print only once; "PETSC_COMM_WORLD" means collective over all processors
  ierr = PetscPrintf(PETSC_COMM_WORLD,"size = %d\n",size);CHKERRQ(ierr);

  ierr = PetscFinalize(); CHKERRQ(ierr);
  return 0;
}
