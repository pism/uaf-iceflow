/*
$ mpiexec -n 6 ./daNvecs -M 600 -N 453
  grid ranges for rank 5 process:  xs=400, xm=200, ys=227, ym=226
  grid ranges for rank 4 process:  xs=200, xm=200, ys=227, ym=226
  grid ranges for rank 2 process:  xs=400, xm=200, ys=0, ym=227
  whole grid size is 600 x 453
  grid ranges for rank 0 process:  xs=0, xm=200, ys=0, ym=227
  grid ranges for rank 3 process:  xs=0, xm=200, ys=227, ym=226
  grid ranges for rank 1 process:  xs=200, xm=200, ys=0, ym=227
*/

static char help[] = "Creates 2d DA and DA-managed Vecs.\n";

#include <petscda.h>

int main(int argc, char *argv[]) {
  PetscErrorCode  ierr;
  PetscMPIInt     rank;
  PetscInt        myM = 50, myN = 53;
  DA 	            da2;
  DALocalInfo     info;
  Vec             vv;

  // start up and read options
  ierr = PetscInitialize(&argc, &argv, PETSC_NULL, help); CHKERRQ(ierr);
  ierr = MPI_Comm_rank(PETSC_COMM_WORLD, &rank); CHKERRQ(ierr);
  ierr = PetscOptionsGetInt(PETSC_NULL, "-M", &myM, PETSC_NULL); CHKERRQ(ierr);
  ierr = PetscOptionsGetInt(PETSC_NULL, "-N", &myN, PETSC_NULL); CHKERRQ(ierr);

  // create DA which is periodic and has (star) stencil width 1
  ierr = DACreate2d(PETSC_COMM_WORLD, DA_XYPERIODIC, DA_STENCIL_STAR, myM, myN, 
             PETSC_DECIDE, PETSC_DECIDE, 1, 1, PETSC_NULL, PETSC_NULL, &da2); CHKERRQ(ierr);
  ierr = DAGetLocalInfo(da2, &info); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_WORLD,"  whole grid size is %d x %d\n",myM,myN); CHKERRQ(ierr);
  ierr = PetscPrintf(PETSC_COMM_SELF,"  grid ranges for rank %d process:  xs=%d, xm=%d, ys=%d, ym=%d\n",
                     rank,info.xs,info.xm,info.ys,info.ym);CHKERRQ(ierr);
  ierr = DACreateGlobalVector(da2, &vv); CHKERRQ(ierr);

  // do something with vv; each processor may access the part of vv indicated by info

  // destroy everything
  ierr = VecDestroy(vv); CHKERRQ(ierr);
  ierr = DADestroy(da2); CHKERRQ(ierr);
  ierr = PetscFinalize(); CHKERRQ(ierr);
  return 0;
}
